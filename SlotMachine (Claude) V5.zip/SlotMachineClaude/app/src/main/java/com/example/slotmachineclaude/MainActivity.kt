// Change this package name to match YOUR project
package com.example.slotmachineclaude

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import android.annotation.SuppressLint
import android.media.MediaPlayer

@SuppressLint("SetTextI18n")
class MainActivity : AppCompatActivity() {

    private lateinit var slot1: TextView
    private lateinit var slot2: TextView
    private lateinit var slot3: TextView
    private lateinit var spinButton: Button
    private lateinit var balanceText: TextView
    private lateinit var betText: TextView
    private lateinit var resultText: TextView

    private var balance = 1000
    private var bet = 10
    private var isSpinning = false

    private val symbols = listOf("🍒", "🍋", "🍊", "🍇", "🔔", "💎", "7️⃣")
    private val handler = Handler(Looper.getMainLooper())
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        updateBalance()
    }

    private fun initViews() {
        slot1 = findViewById(R.id.slot1)
        slot2 = findViewById(R.id.slot2)
        slot3 = findViewById(R.id.slot3)
        spinButton = findViewById(R.id.spinButton)
        balanceText = findViewById(R.id.balanceText)
        betText = findViewById(R.id.betText)
        resultText = findViewById(R.id.resultText)

        spinButton.setOnClickListener { spin() }

        findViewById<Button>(R.id.increaseBet).setOnClickListener {
            if (bet < balance && bet < 100) {
                bet += 10
                updateBalance()
            }
        }

        findViewById<Button>(R.id.decreaseBet).setOnClickListener {
            if (bet > 10) {
                bet -= 10
                updateBalance()
            }
        }
    }

    private fun spin() {
        if (isSpinning) return

        if (balance < bet) {
            Toast.makeText(this, "Insufficient balance!", Toast.LENGTH_SHORT).show()
            return
        }

        isSpinning = true
        balance -= bet
        updateBalance()
        resultText.text = "Spinning..."
        spinButton.isEnabled = false

        // Animate slots
        animateSlot(slot1, 0)
        animateSlot(slot2, 300)
        animateSlot(slot3, 600)

        // Final results after animations
        handler.postDelayed({
            val result1 = symbols.random()
            val result2 = symbols.random()
            val result3 = symbols.random()

            slot1.text = result1
            slot2.text = result2
            slot3.text = result3

            checkWin(result1, result2, result3)
            isSpinning = false
            spinButton.isEnabled = true
        }, 2000)
    }

    private fun animateSlot(slot: TextView, delay: Long) {
        handler.postDelayed({
            var spinCount = 0
            val spinRunnable = object : Runnable {
                override fun run() {
                    slot.text = symbols.random()
                    spinCount++
                    if (spinCount < 15) {
                        handler.postDelayed(this, 100)
                    }
                }
            }
            handler.post(spinRunnable)
        }, delay)
    }

    private fun playWinSound() {
        try {
            // Using a system sound as a placeholder since there are no custom sounds in res/raw
            // In a real app, you would add a sound file to res/raw/win_sound.mp3
            // and use MediaPlayer.create(this, R.raw.win_sound)
            
            // Releasing previous player if it exists
            mediaPlayer?.release()
            
            // Try to use a common system sound or just log if not available
            // For now, I'll set up the code structure. You should add a 'win.mp3' to 'app/src/main/res/raw/'
            val soundResId = resources.getIdentifier("win", "raw", packageName)
            if (soundResId != 0) {
                mediaPlayer = MediaPlayer.create(this, soundResId)
                mediaPlayer?.start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun checkWin(s1: String, s2: String, s3: String) {
        var won = false
        when {
            s1 == s2 && s2 == s3 -> {
                val winnings = when (s1) {
                    "7️⃣" -> bet * 50
                    "💎" -> bet * 30
                    "🔔" -> bet * 20
                    else -> bet * 10
                }
                balance += winnings
                resultText.text = "JACKPOT! Won $winnings!"
                resultText.setTextColor(getColor(android.R.color.holo_green_dark))
                won = true
            }
            s1 == s2 || s2 == s3 || s1 == s3 -> {
                val winnings = bet * 2
                balance += winnings
                resultText.text = "Won $winnings!"
                resultText.setTextColor(getColor(android.R.color.holo_orange_dark))
                won = true
            }
            else -> {
                resultText.text = "Try again!"
                resultText.setTextColor(getColor(android.R.color.holo_red_dark))
            }
        }
        
        if (won) {
            playWinSound()
        }
        
        updateBalance()

        if (balance < bet) {
            Toast.makeText(this, "Game Over! Restarting with 1000 coins", Toast.LENGTH_LONG).show()
            handler.postDelayed({
                balance = 1000
                updateBalance()
            }, 2000)
        }
    }

    private fun updateBalance() {
        balanceText.text = "Balance: $balance"
        betText.text = "Bet: $bet"
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
